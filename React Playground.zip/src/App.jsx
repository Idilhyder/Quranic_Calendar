import React, { useState, useMemo } from 'react';
import { FaCheck, FaMoon, FaChevronLeft, FaChevronRight } from 'react-icons/fa';

const quranicMonthColors = {
  "Muharram": "#d1e7dd",
  "Safar": "#fefae0",
  "Rabiʿ al-Awwal": "#fde2e4",
  "Rabiʿ ath-Thani": "#d6e4f0",
  "Jumada al-Awwal": "#f0efeb",
  "Jumada ath-Thani": "#e0eafc",
  "Rajab": "#fff0f5",
  "Shaʿbān": "#ffe5b4",
  "Ramaḍān": "#fff8dc",
  "Shawwāl": "#e6e6fa",
  "Dhū al-Qaʿdah": "#f5f5dc",
  "Dhū al-Ḥijjah": "#faf0e6"
};

const hilalNotes = {
  "April 2025": "🌙 Hilāl appeared on April 23 — Jumada al-Awwal began on April 24. (Source: Qur’an 2:189; based on moon visibility models — timeanddate.com)",
  "May 2025": "🌙 Hilāl appeared on May 23 — Jumada ath-Thani began on May 24. (Source: Qur’an 2:189; based on moon visibility models — timeanddate.com)",
  "June 2025": "🌙 Hilāl appeared on June 21 — Rajab began on June 22. (Source: Qur’an 2:189; based on moon visibility models — timeanddate.com)"
};

const calendarData = {
  "April 2025": {
    startOffset: 1,
    days: Array.from({ length: 30 }, (_, i) => {
      const day = i + 1;
      const date = new Date(2025, 3, day);
      const quranicMonth = day <= 23 ? "Rabiʿ ath-Thani" : "Jumada al-Awwal";
      const quranicDay = day <= 23 ? day + 1 : day - 23;
      const isHilal = day === 24;
      return { day, date, quranicMonth, quranicDay, isHilal };
    })
  },
  "May 2025": {
    startOffset: 4,
    days: Array.from({ length: 31 }, (_, i) => {
      const day = i + 1;
      const date = new Date(2025, 4, day);
      const quranicMonth = day <= 23 ? "Jumada al-Awwal" : "Jumada ath-Thani";
      const quranicDay = day <= 23 ? day + 7 : day - 23;
      const isHilal = day === 24;
      return { day, date, quranicMonth, quranicDay, isHilal };
    })
  },
  "June 2025": {
    startOffset: 0,
    days: Array.from({ length: 30 }, (_, i) => {
      const day = i + 1;
      const date = new Date(2025, 5, day);
      const quranicMonth = day <= 21 ? "Jumada ath-Thani" : "Rajab";
      const quranicDay = day <= 21 ? day + 8 : day - 21;
      const isHilal = day === 22;
      return { day, date, quranicMonth, quranicDay, isHilal };
    })
  }
};

const isPast = (date) => new Date() > date;

function DayCell({ day, date, quranicMonth, quranicDay, isHilal }) {
  return (
    <div
      className="relative border border-gray-300 p-2 rounded shadow-sm"
      style={{ backgroundColor: quranicMonthColors[quranicMonth] || 'white' }}
    >
      <div className="text-xs font-medium">{day}</div>
      <div className="text-[10px] text-gray-700">{quranicDay} {quranicMonth}</div>
      {isHilal && <FaMoon className="absolute top-1 right-1 w-4 h-4 text-blue-500" />}
      {isPast(date) && <FaCheck className="absolute bottom-1 right-1 w-4 h-4 text-green-500" />}
    
</div>
  );
}

export default function QuranicCalendar() {
  const monthKeys = useMemo(() => Object.keys(calendarData), []);
  const [currentMonthIndex, setCurrentMonthIndex] = useState(0);
  const currentMonthKey = monthKeys[currentMonthIndex];
  const { startOffset, days } = calendarData[currentMonthKey];

  const prevMonth = () => setCurrentMonthIndex((prev) => (prev > 0 ? prev - 1 : prev));
  const nextMonth = () => setCurrentMonthIndex((prev) => (prev < monthKeys.length - 1 ? prev + 1 : prev));

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 p-6 font-sans">
      <header className="text-center mb-6 flex justify-between items-center max-w-5xl mx-auto">
        <button onClick={prevMonth} className="text-gray-500 hover:text-gray-800">
          <FaChevronLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold">Quranic Calendar</h1>
          <p className="text-md text-gray-600">{currentMonthKey}</p>
        </div>
        <button onClick={nextMonth} className="text-gray-500 hover:text-gray-800">
          <FaChevronRight className="w-5 h-5" />
        </button>
      </header>

      <div className="grid grid-cols-7 gap-2 max-w-5xl mx-auto">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
          <div key={d} className="text-center font-semibold text-sm text-gray-500">
            {d}
          </div>
        ))}

        {Array.from({ length: startOffset }, (_, i) => (
          <div key={`offset-${i}`} className="" />
        ))}

        {days.map((dayObj) => (
          <DayCell key={dayObj.day} {...dayObj} />
        ))}
      </div>

      <div className="text-center text-xs text-gray-500 mt-4 italic">
        {hilalNotes[currentMonthKey] || ""}
      </div>

      <div className="text-center text-[10px] text-gray-400 mt-1">
        *The new moon (conjunction) is not visible. The hilāl appears about a day later and marks the true start of the month (Qur’an 2:189).
      </div>
    </div>
  );
}
